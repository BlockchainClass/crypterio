(function (angular) {

    angular.bootstrap(document,['VCW_FrontedApp'])

})(angular);